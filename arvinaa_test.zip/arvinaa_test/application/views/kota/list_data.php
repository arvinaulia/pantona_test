<?php
  $no = 1;
  foreach ($dataKota as $user) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $user->email; ?></td>
      <td><?php echo $user->nama; ?></td>
      <td><?php echo $user->password; ?></td>
      <td><?php echo $user->foto; ?></td>
     <!-- <td class="text-center" style="min-width:100px;">
          <button class="btn btn-warning update-dataKota" data-id="<?php echo $user->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Update</button>
          <button class="btn btn-danger konfirmasiHapus-kota" data-id="<?php echo $user->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Delete</button>
          <button class="btn btn-info detail-dataKota" data-id="<?php echo $user->id; ?>"><i class="glyphicon glyphicon-info-sign"></i> Detail</button>
      </td> -->
    </tr>
    <?php
    $no++;
  }
?>